/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { PintableDirective as ɵa } from './lib/pintable.directive';
