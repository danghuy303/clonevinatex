(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core')) :
    typeof define === 'function' && define.amd ? define('voi-lib', ['exports', '@angular/core'], factory) :
    (global = global || self, factory(global['voi-lib'] = {}, global.ng.core));
}(this, (function (exports, i0) { 'use strict';

    var VoiLibService = /** @class */ (function () {
        function VoiLibService() {
        }
        return VoiLibService;
    }());
    VoiLibService.ɵprov = i0.ɵɵdefineInjectable({ factory: function VoiLibService_Factory() { return new VoiLibService(); }, token: VoiLibService, providedIn: "root" });
    VoiLibService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    VoiLibService.ctorParameters = function () { return []; };

    var VoiLibComponent = /** @class */ (function () {
        function VoiLibComponent() {
        }
        VoiLibComponent.prototype.ngOnInit = function () {
        };
        return VoiLibComponent;
    }());
    VoiLibComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'lib-voi-lib',
                    template: "\n    <p>\n      voi-lib works!\n    </p>\n  "
                },] }
    ];
    VoiLibComponent.ctorParameters = function () { return []; };

    var PintableDirective = /** @class */ (function () {
        function PintableDirective(elementRef, renderer) {
            this.elementRef = elementRef;
            this.renderer = renderer;
            this.pinnedCols = 0;
        }
        PintableDirective.prototype.ngAfterViewInit = function () {
            this.active();
        };
        PintableDirective.prototype.active = function () {
            this.renderer.listen(this.elementRef.nativeElement.querySelector('tbody'), 'scroll', this.onScroll.bind(this));
        };
        PintableDirective.prototype.onScroll = function (event) {
            var _this = this;
            var header = this.elementRef.nativeElement.querySelector('thead');
            var body = this.elementRef.nativeElement.querySelector('tbody');
            header.style.transform = "translateX(-" + event.srcElement.scrollLeft + "px)";
            if (this.pinnedCols > 0) {
                header.childNodes.forEach(function (tr) {
                    var _a, _b;
                    var n = _this.pinnedCols;
                    for (var i = 0; i < n; i++) {
                        if (((_a = tr.childNodes[i]) === null || _a === void 0 ? void 0 : _a.style) !== null && ((_b = tr.childNodes[i]) === null || _b === void 0 ? void 0 : _b.style) !== undefined) {
                            tr.childNodes[i].style.position = "relative";
                            tr.childNodes[i].style.transform = "translate(" + event.srcElement.scrollLeft + "px)";
                        }
                    }
                });
                body.childNodes.forEach(function (tr) {
                    var _a, _b;
                    for (var i = 0; i < _this.pinnedCols; i++) {
                        if (((_a = tr.childNodes[i]) === null || _a === void 0 ? void 0 : _a.style) !== null && ((_b = tr.childNodes[i]) === null || _b === void 0 ? void 0 : _b.style) !== undefined) {
                            tr.childNodes[i].style.position = "relative";
                            tr.childNodes[i].style.transform = "translate(" + event.srcElement.scrollLeft + "px)";
                        }
                    }
                });
            }
        };
        return PintableDirective;
    }());
    PintableDirective.decorators = [
        { type: i0.Directive, args: [{
                    selector: '[voiPintable]'
                },] }
    ];
    PintableDirective.ctorParameters = function () { return [
        { type: i0.ElementRef },
        { type: i0.Renderer2 }
    ]; };
    PintableDirective.propDecorators = {
        pinnedCols: [{ type: i0.Input, args: ['pinnedCols',] }]
    };

    var VoiLibModule = /** @class */ (function () {
        function VoiLibModule() {
        }
        return VoiLibModule;
    }());
    VoiLibModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [VoiLibComponent, PintableDirective],
                    imports: [],
                    exports: [VoiLibComponent, PintableDirective]
                },] }
    ];

    /*
     * Public API Surface of voi-lib
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.VoiLibComponent = VoiLibComponent;
    exports.VoiLibModule = VoiLibModule;
    exports.VoiLibService = VoiLibService;
    exports.ɵa = PintableDirective;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=voi-lib.umd.js.map
