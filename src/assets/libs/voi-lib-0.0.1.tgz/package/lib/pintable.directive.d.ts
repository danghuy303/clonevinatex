import { AfterViewInit, ElementRef, Renderer2 } from '@angular/core';
export declare class PintableDirective implements AfterViewInit {
    private elementRef;
    private renderer;
    pinnedCols: number;
    constructor(elementRef: ElementRef, renderer: Renderer2);
    ngAfterViewInit(): void;
    active(): void;
    onScroll(event: any): void;
}
