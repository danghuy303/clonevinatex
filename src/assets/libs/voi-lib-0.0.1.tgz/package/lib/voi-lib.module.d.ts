export declare class VoiLibModule {
}
