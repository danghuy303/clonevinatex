import { OnInit } from '@angular/core';
export declare class VoiLibComponent implements OnInit {
    constructor();
    ngOnInit(): void;
}
