export declare class VoiLibService {
    constructor();
}
