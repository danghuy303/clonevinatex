import { ɵɵdefineInjectable, Injectable, Component, Directive, ElementRef, Renderer2, Input, NgModule } from '@angular/core';

class VoiLibService {
    constructor() { }
}
VoiLibService.ɵprov = ɵɵdefineInjectable({ factory: function VoiLibService_Factory() { return new VoiLibService(); }, token: VoiLibService, providedIn: "root" });
VoiLibService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
VoiLibService.ctorParameters = () => [];

class VoiLibComponent {
    constructor() { }
    ngOnInit() {
    }
}
VoiLibComponent.decorators = [
    { type: Component, args: [{
                selector: 'lib-voi-lib',
                template: `
    <p>
      voi-lib works!
    </p>
  `
            },] }
];
VoiLibComponent.ctorParameters = () => [];

class PintableDirective {
    constructor(elementRef, renderer) {
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.pinnedCols = 0;
    }
    ngAfterViewInit() {
        this.active();
    }
    active() {
        this.renderer.listen(this.elementRef.nativeElement.querySelector('tbody'), 'scroll', this.onScroll.bind(this));
    }
    onScroll(event) {
        let header = this.elementRef.nativeElement.querySelector('thead');
        let body = this.elementRef.nativeElement.querySelector('tbody');
        header.style.transform = `translateX(-${event.srcElement.scrollLeft}px)`;
        if (this.pinnedCols > 0) {
            header.childNodes.forEach(tr => {
                var _a, _b;
                let n = this.pinnedCols;
                for (let i = 0; i < n; i++) {
                    if (((_a = tr.childNodes[i]) === null || _a === void 0 ? void 0 : _a.style) !== null && ((_b = tr.childNodes[i]) === null || _b === void 0 ? void 0 : _b.style) !== undefined) {
                        tr.childNodes[i].style.position = `relative`;
                        tr.childNodes[i].style.transform = `translate(${event.srcElement.scrollLeft}px)`;
                    }
                }
            });
            body.childNodes.forEach(tr => {
                var _a, _b;
                for (let i = 0; i < this.pinnedCols; i++) {
                    if (((_a = tr.childNodes[i]) === null || _a === void 0 ? void 0 : _a.style) !== null && ((_b = tr.childNodes[i]) === null || _b === void 0 ? void 0 : _b.style) !== undefined) {
                        tr.childNodes[i].style.position = `relative`;
                        tr.childNodes[i].style.transform = `translate(${event.srcElement.scrollLeft}px)`;
                    }
                }
            });
        }
    }
}
PintableDirective.decorators = [
    { type: Directive, args: [{
                selector: '[voiPintable]'
            },] }
];
PintableDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: Renderer2 }
];
PintableDirective.propDecorators = {
    pinnedCols: [{ type: Input, args: ['pinnedCols',] }]
};

class VoiLibModule {
}
VoiLibModule.decorators = [
    { type: NgModule, args: [{
                declarations: [VoiLibComponent, PintableDirective],
                imports: [],
                exports: [VoiLibComponent, PintableDirective]
            },] }
];

/*
 * Public API Surface of voi-lib
 */

/**
 * Generated bundle index. Do not edit.
 */

export { VoiLibComponent, VoiLibModule, VoiLibService, PintableDirective as ɵa };
//# sourceMappingURL=voi-lib.js.map
